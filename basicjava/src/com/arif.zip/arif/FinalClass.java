package com.arif;

public final class FinalClass {

}

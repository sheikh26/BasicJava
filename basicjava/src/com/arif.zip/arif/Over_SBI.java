package com.arif;

public class Over_SBI extends  OverriddingBank{
	int getRateOfInterest()
	{
		return 8;
		}  	

}

package com.arif;

public class Over_AXIS extends  OverriddingBank{
	int getRateOfInterest()
	{
		return 9;
		}  	

}

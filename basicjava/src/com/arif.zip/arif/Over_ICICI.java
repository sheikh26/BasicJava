package com.arif;

public class Over_ICICI extends  OverriddingBank{
	int getRateOfInterest()
	{
		return 7;
		}  	

}

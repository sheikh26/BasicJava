package com.arif;

public class InheritanceAnimal {
	
	void eat(){
		System.out.println("eating...");
	}  
}

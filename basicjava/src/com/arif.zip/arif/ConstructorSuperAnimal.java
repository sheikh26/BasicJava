package com.arif;

public class ConstructorSuperAnimal {
	
	String color="white";  
}

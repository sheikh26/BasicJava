package com.arif;

public class EncapsulationClass {
	//private data member  
	private String name;  
	//getter method for name  

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	}  

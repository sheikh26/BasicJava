package com.arif;

public class FinalMethodBike {
	final void run(){
		  System.out.println("running");
		  }  
	}  
	     

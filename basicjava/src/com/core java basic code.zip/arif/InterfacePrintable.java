package com.arif;

public interface InterfacePrintable {
	void print();  

}

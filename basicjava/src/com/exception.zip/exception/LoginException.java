package com.exception;

class LoginException extends Exception {

	public LoginException(String s) {
		super(s);
	} // constructor

}

/**
 * Java training example source code developed by Galaxy Technologies, Indore
 * Copyright (c) 2008 Galaxy Technologies
 * @date 08/08/08
 * @version 1.0
 * @author Arif Sheikh
 * 
 */

public class HelloDoWhile {

	public static void main(String[] args) {
		int i = 0;
		do {

			System.out.println( i+ " Hello Java ");
			i++;
		} while (i < 5);
	}
}

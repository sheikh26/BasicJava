/**
 * Java training example source code developed by Galaxy Technologies, Indore
 * Copyright (c) 2008 Galaxy Technologies
 * 
 * @date 08/08/08
 * @version 1.0
 * @author Arif Sheikh
 * 
 * Declare int variables and sum them
 */

public class SumNum {

	public static void main(String[] args) {
		int a = 5;
		int b = 10;
		int sum = a + b;
		System.out.println("Sum is " + sum);

	}

}

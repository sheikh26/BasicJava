
public class FinalMethodCall extends FinalMethodBike{

	void run()
	{
		System.out.println("running safely with 100kmph");
		}  
    
	   public static void main(String args[]){  
		   FinalMethodCall honda= new FinalMethodCall();  
	   honda.run();  
	   }  
}

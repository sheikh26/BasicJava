/**
 * Java training example source code developed by Galaxy Technologies, Indore
 * Copyright (c) 2008 Galaxy Technologies
 * 
 * @date 08/08/08
 * @version 1.0
 * @author Arif Sheikh
 * 
 */

public class HelloWhile {

	public static void main(String[] args) {
		int i = 0;
		while (i < 5) {

			System.out.println("Hello Java ");
			i++;
		}
	}
}

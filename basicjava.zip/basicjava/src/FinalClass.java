
public final class FinalClass {

}

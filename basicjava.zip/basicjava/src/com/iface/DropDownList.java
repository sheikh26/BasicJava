package com.iface;

public interface DropDownList {
	
	//An interface can contain only constants and method declarations
	
	public final int NO_OF_LIST = 1;

	public String getKey();

	public String getValue();

}

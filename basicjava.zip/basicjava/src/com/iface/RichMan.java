package com.iface;

public interface RichMan {

	public void earnMony();

	public void donation();

	public void party();
}

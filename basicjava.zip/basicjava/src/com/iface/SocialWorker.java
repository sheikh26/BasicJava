package com.iface;

public interface SocialWorker{
	public void helpToOthers();
}

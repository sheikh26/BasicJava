package com.dto;

public class Point {

	public int x;

	public  int y;
	
    private  int z;	
	
    public int getZ(){
    	return z;
    }

}

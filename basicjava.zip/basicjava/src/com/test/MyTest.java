package com.test;

import com.basic.Shape;



public class MyTest {

	public static void main(String[] args) {
		
/*		Shape s = new Shape("Black",300);
		System.out.println("Color is " + s.getColor());*/

	}

}

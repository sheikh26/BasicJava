package com.test;

import com.basic.Rectangle;
import com.basic.Shape;

public class TestCircle {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Shape s = new Rectangle();
		Rectangle r = (Rectangle)s;
		
	}

}

package com.swing;

public class Test {

	public static void main(String[] args) {
		MyFirstWindow frame = new MyFirstWindow();
		frame.setVisible(true);
	}

}

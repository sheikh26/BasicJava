package com.arif;

 public class Employee {
	
	float salary=40000;  
	}  
  class Programmer extends Employee{  
	 int bonus=10000;  
	 

}

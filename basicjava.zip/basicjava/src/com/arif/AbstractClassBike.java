package com.arif;

public abstract class AbstractClassBike {
	
	 abstract void run();  
	 
	 void changeGear(){
		 System.out.println("gear changed");
		 }  
}

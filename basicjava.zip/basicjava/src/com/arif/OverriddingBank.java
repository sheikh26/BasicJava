package com.arif;

public class OverriddingBank {
	
	int getRateOfInterest()
	{
		return 0;
		} 
}

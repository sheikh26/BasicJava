package com.arif;
/**
 * Java training example source code developed by Galaxy Tech, Indore
 * Copyright (c) 2008 Galaxy Tech
 * @date 08/08/08
 * @version 1.0
 * @author Arif Sheikh
 * 
 */

public class HelloJava {

	public static void main(String[] args) {
		String name = "arif sheikh"; 
		System.out.println(name);

	}

}

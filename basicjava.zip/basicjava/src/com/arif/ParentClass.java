package com.arif;

public class ParentClass {
	
	void test() {
		System.out.println("Parent");
	}

}

package com.arif;

public class ConstructorThisStudentTest {
	
	public static void main(String args[]){  
		
		ConstructorThisStudent s1=new ConstructorThisStudent(111,"ankit",5000f);  
		ConstructorThisStudent s2=new ConstructorThisStudent(112,"sumit",6000f);  
		
		s1.display();  
		s2.display();  
		}
}

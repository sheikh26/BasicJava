package com.arif;

public interface InterfacePrintable {
	void print();  
	void print1(); 
	void print2(); 
}
package com.basic;

public class Parent {

	private String att = "Val Parent";

	public Parent() {
		// TODO Auto-generated constructor stub
	}

	public String getAtt() {
		return this.att;
	}

}

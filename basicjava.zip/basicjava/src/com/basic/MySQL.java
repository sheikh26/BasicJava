package com.basic;

public class MySQL extends Database {
	public String getData() {
		return "MySQL Data";
	}

}

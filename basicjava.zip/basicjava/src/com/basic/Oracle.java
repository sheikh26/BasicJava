package com.basic;

public class Oracle extends Database {
	public String getData() {
		return "Oracle Data";

	}

}

package com.basic;

public class Database {
	public String getData() {
		return null;

	}
}

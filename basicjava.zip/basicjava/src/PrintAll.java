
public class PrintAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printAll(args);
	}
	
	public static void printAll(String[] args) {
		for (int i=0; i<args.length;i++) {
			System.out.println("Hello "+ args[i]);
		}
		}
		
	}
	

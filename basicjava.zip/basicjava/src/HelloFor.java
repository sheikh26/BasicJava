/**
 * Java training example source code developed by Galaxy Technologies, Indore
 * Copyright (c) 2008 Galaxy Technologies
 * 
 * @date 08/08/08
 * @version 1.0
 * @author Arif Sheikh
 * 
 */

public class HelloFor {

	public static void main(String[] args) {

		for (int i = 0; i < 5; i++) {

			System.out.println("Hello Java ");
		}
	}
}
